import 'package:travelapp/model/country_model.dart';

import '../model/popular_tours_model.dart';

List<countryModel> getCountries() {
  List<countryModel> country = [];
  countryModel obj = new countryModel();
  //1
  obj.countryName = "Paris";
  obj.label = "New";
  obj.noOfTours = 10;
  obj.rating = 4.5;
  obj.imgUrl =
      "https://images.pexels.com/photos/2267339/pexels-photo-2267339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //2
  obj.countryName = "THailand";
  obj.label = "New";
  obj.noOfTours = 10;
  obj.rating = 4.2;
  obj.imgUrl =
      "https://images.pexels.com/photos/3225520/pexels-photo-3225520.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //3
  obj.countryName = "Singapur";
  obj.label = "New";
  obj.noOfTours = 10;
  obj.rating = 4.1;
  obj.imgUrl =
      "https://images.pexels.com/photos/11048064/pexels-photo-11048064.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //4
  obj.countryName = "Norway";
  obj.label = "New";
  obj.noOfTours = 5;
  obj.rating = 4.5;
  obj.imgUrl =
      "https://images.pexels.com/photos/2267339/pexels-photo-2267339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //5
  obj.countryName = "Dubai";
  obj.label = "New";
  obj.noOfTours = 6;
  obj.rating = 4.3;
  obj.imgUrl =
      "https://images.pexels.com/photos/2267339/pexels-photo-2267339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //6
  obj.countryName = "Europe";
  obj.label = "New";
  obj.noOfTours = 10;
  obj.rating = 4.5;
  obj.imgUrl =
      "https://images.pexels.com/photos/2267339/pexels-photo-2267339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //7
  obj.countryName = "Canada";
  obj.label = "New";
  obj.noOfTours = 3;
  obj.rating = 4.1;
  obj.imgUrl =
      "https://images.pexels.com/photos/2516418/pexels-photo-2516418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //8
  obj.countryName = "Australia";
  obj.label = "New";
  obj.noOfTours = 10;
  obj.rating = 4.5;
  obj.imgUrl =
      "https://images.pexels.com/photos/2267339/pexels-photo-2267339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //9
  obj.countryName = "Manali";
  obj.label = "New";
  obj.noOfTours = 10;
  obj.rating = 4.5;
  obj.imgUrl =
      "https://images.pexels.com/photos/2179666/pexels-photo-2179666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  //10
  obj.countryName = "Goa";
  obj.label = "New";
  obj.noOfTours = 10;
  obj.rating = 4.5;
  obj.imgUrl =
      "https://images.pexels.com/photos/2964163/pexels-photo-2964163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  country.add(obj);
  obj = new countryModel();
  return country;
}

List<popularTourModel> getpop() {
  List<popularTourModel> populart = [];
  popularTourModel obj = new popularTourModel();
  //1
  obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();
  //2
  obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();
  //3
  obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();
  //4
  obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();
  //5
  obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();
obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();
obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();
 obj.tittle = "Thailand";
  obj.desc = "10 nigths for two/all inclusive";
  obj.rating = 4.2;
  obj.price = "\$ 345.00";
  obj.imgurl = "https://images.pexels.com/photos/6051693/pexels-photo-6051693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
  populart.add(obj);
  obj = new popularTourModel();

  return populart;
}
