class countryModel {
  String? label;
  String? countryName;
  int? noOfTours;
  double? rating;
  String? imgUrl;
  //CountryListTIle({super.label});
  countryModel({this.countryName, this.label, this.noOfTours, this.rating,this.imgUrl});
}
