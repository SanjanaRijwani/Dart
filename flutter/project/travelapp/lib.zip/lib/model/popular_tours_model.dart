class popularTourModel {
  String? imgurl;
  String? tittle;
  String? desc;
  String? price;
  double? rating;
  popularTourModel(
      {this.desc, this.imgurl, this.price, this.rating, this.tittle});
}
